/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import sw.Service;
import sw.Service_Service;

/**
 *
 * @author 59399
 */
public class Client {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Service_Service servicios = new Service_Service();
        Service cliente = servicios.getServicePort();
        if (cliente.login("CarlosTH", "12345")) {
            System.out.println("Correcto");
        } else {
            System.out.println("Incorrecto");
        }
    }

}
